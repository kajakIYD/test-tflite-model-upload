#!/bin/bash


ls -la /home/pi/jbudzilo/soundfiles
