librosa.sh - instalacja biblioteki librosa, potrzebnej do ekstrakcji cech z dźwięku
models - modele, które są zaciągane przez skrypty pythona
python_scripts - tu znajduje się główny plik projektu -> sound_recorder_and_classfier.py
sample_from_tf_github# - run.sh - sprawdzenie, czy tensorflow lite działa poprawnie na Raspberry
seed-voicecard - instalacja shielda z mikrofonami
service - żeby program działał sam po włączeniu raspberry
soundfiles - tam są wrzucane nagrywane pliki audio
tensorflow_normal_and_lite - instalacja tensorflow lite i zwykłego tensorflow
