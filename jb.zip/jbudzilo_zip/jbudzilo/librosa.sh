#!/bin/bash


sudo apt-get update --allow-releaseinfo-change

# sudo apt install libblas-dev llvm python3-pip python3-scipy -y
sudo apt install llvm

LLVM_CONFIG=$(which llvm-config) python3 -m pip install llvmlite==0.32

python3 -m pip install numpy==1.16.1 numba==0.49

python3 -m pip install scikit-learn==0.23.2
python3 -m pip install librosa==0.8.0
