#!/bin/bash

gdown https://drive.google.com/uc?id=1-W39CIHJIGQYCQBxj-iDcsNXroW0UMA5

gdown https://drive.google.com/uc?id=1-eDO0tiGRWhs1JMtnFgpaRNbtVKhjQDD
