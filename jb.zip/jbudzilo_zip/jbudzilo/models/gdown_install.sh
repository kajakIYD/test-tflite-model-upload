#!/bin/bash


python3 -m pip install gdown

gdown --folder https://drive.google.com/drive/folders/1HZZCK8kKREJJgLGaFCWC7oAjylMOC4TC?usp=sharing
