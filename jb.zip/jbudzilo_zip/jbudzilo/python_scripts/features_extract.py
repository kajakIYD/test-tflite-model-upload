import librosa
import numpy as np


# do feature extraction using librosa
def features_extract(file_name):
    # audio - przebieg czasowy tego sygnalu przedstawienie pliku dzwiekowego za pomoca wykresu (wektor kilutysiecy liczb)
    # sample_rate - jak duzo jest próbek w sekundzie dźwięku ktore pobiera komputer
    audio,sample_rate = librosa.load(file_name,res_type='kaiser_fast')
    
    # extract the features
    feature = librosa.feature.mfcc(y=audio,sr=sample_rate,n_mfcc=50)
    
    # feature scaling
    scaled_feature = np.mean(feature.T,axis=0)
    
    # return the scaled features
    return scaled_feature


if __name__ == "__main__":
    tmp = features_extract("../soundfiles/test1.wav")
    print(tmp)
