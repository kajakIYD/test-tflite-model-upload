#!/bin/bash


systemctl status sound_recorder_and_classifier
