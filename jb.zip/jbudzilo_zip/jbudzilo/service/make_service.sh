#!/bin/bash


cp sound_recorder_and_classifier.service /etc/systemd/system

sudo systemctl daemon-reload
sudo systemctl enable sound_recorder_and_classifier
sudo systemctl start sound_recorder_and_classifier
