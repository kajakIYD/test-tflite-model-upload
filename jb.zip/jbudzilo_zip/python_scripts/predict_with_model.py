import numpy as np
import tflite_runtime.interpreter as tflite


CLASSES = {
0: "dog_bark",
1: "children_playing",
2: "car_horn",
3: "air_conditioner",
4: "street_music",
5: "gun_shot",
6: "siren",
7: "engine_idling",
8: "jackhammer",
9: "drilling"
}

THRESHOLD = 0.5


def label(outputs):
    outputs = outputs.ravel()
    print(outputs)
    print(outputs.shape)
    class_idx = np.argmax(outputs)
#    print(class_idx)
#    print(CLASSES[class_idx])
    if outputs[class_idx] > THRESHOLD:
        return CLASSES[class_idx]
    else:
        return "Not enough confidence level to classify"



def classify(model_path, features):
    # Load TFLite model and allocate tensors.
    interpreter = tflite.Interpreter(
	model_path=model_path
    )
    interpreter.allocate_tensors()

    # Get input and output tensors.
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # Test model on random input data.
    input_shape = input_details[0]['shape']
    input_data = np.array(np.random.random_sample(input_shape), dtype=np.float32)
    interpreter.set_tensor(input_details[0]['index'], input_data)

    interpreter.invoke()

    # The function `get_tensor()` returns a copy of the tensor data.
    # Use `tensor()` in order to get a pointer to the tensor.
    output_data = interpreter.get_tensor(output_details[0]['index'])
    print(output_data)
    return output_data


if __name__ == "__main__":
	# Load TFLite model and allocate tensors.
	interpreter = tflite.Interpreter(
            model_path="models/sound_tflite_19_02_6_00.tflite"
#tflite_simple_from_git.tflite"
#model_from_tflite_convert_from_git.tflite"
#model_from_saved_model_from_git.tflite"
        )
#model.tflite")
	interpreter.allocate_tensors()

#	signatures = interpreter.get_signature_list()
#	print('Signature:', signatures)

	# Get input and output tensors.
	input_details = interpreter.get_input_details()
	output_details = interpreter.get_output_details()

	# Test model on random input data.
	input_shape = input_details[0]['shape']
	input_data = np.array(np.random.random_sample(input_shape), dtype=np.float32)
	interpreter.set_tensor(input_details[0]['index'], input_data)

	interpreter.invoke()

	# The function `get_tensor()` returns a copy of the tensor data.
	# Use `tensor()` in order to get a pointer to the tensor.
	output_data = interpreter.get_tensor(output_details[0]['index'])
	print(output_data)
	label(output_data)
