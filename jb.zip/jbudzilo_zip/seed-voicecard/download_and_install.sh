#!/bin/bash


sudo apt-get update

git clone https://github.com/respeaker/seeed-voicecard.git

cd seeed-voicecard

sudo ./install.sh

sudo reboot now
