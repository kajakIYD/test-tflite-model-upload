#seeed-4mic-voicecard alsa plugin
```
sudo apt install libasound2-dev
make && sudo make install
```