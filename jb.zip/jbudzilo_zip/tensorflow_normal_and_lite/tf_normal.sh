#!/bin/bash

sudo apt-get install libatlas-base-dev -y
sudo apt-get install -y libhdf5-dev libc-ares-dev libeigen3-dev
